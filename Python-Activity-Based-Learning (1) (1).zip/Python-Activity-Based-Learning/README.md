# Python Activity-Based Learning

This repository contains 10 Python ABL case studies prepared using beginner-level Python concepts from the assignment syllabus.

## Case studies
1. Case Study 17 — Student Performance Trend Analysis
2. Case Study 2 — Progressive Electricity Billing
3. Case Study 7 — Retail Billing with Multiple Discount Rules
4. Case Study 12 — Attendance Recovery Computation
5. Case Study 42 — Student Marks Matrix Analysis
6. Case Study 38 — ATM Menu-Driven Banking Simulation
7. Case Study 14 — Warehouse Inventory Reconciliation
8. Case Study 1 — University Scholarship Allocation
9. Case Study 26 — Nested Loop Examination Seating Generator
10. Case Study 57 — Smart Canteen Order and Stock Management

## How to use
Open each numbered folder. Read its `README.md` for the problem statement, objectives, assumptions, algorithm, flowchart, pseudocode, test cases, and conclusion. Run `program.py` using Python 3.

## Before submission
- Run each program and check its behavior.
- Capture real output screenshots and save them as `output.png` in the corresponding folder.
- Confirm your faculty accepts digital documentation and the chosen case studies.
